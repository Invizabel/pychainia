﻿# pychainia is a simple game based off of a popular tower defense game!
# To play on Android: Follow the buildozer guide to install buildozer. Then copy and paste the assets folder as well as the buildozer.spec file into the main folder of your buildoze project from GitHub!
# Then, create a main.py file and add the following lines into the buildozer folder:
# 
# 
# 
#import pychainia
#pychainia.pychainia()
